/**
 * ============================================================
 * KBC S2S Middleware — Subscription Billing Module
 * Stripe Checkout + Customer Portal + Webhooks + Access Gate
 * ============================================================
 *
 * This belongs in your S2S affiliate relay project (Impact.com /
 * PartnerStack middleware) — NOT FlockBlock. FlockBlock's live site
 * is static GitHub Pages with no Express backend to mount this into.
 *
 * WHERE TO PASTE THIS
 *   Save as /routes/billing.js in the S2S middleware Express project.
 *
 * MOUNTING ORDER IN server.js (webhook needs the RAW body):
 *
 *   const billingRoutes = require('./routes/billing');
 *
 *   app.post('/api/billing/webhook',
 *     express.raw({ type: 'application/json' }),
 *     billingRoutes.webhookHandler
 *   );
 *   app.use(express.json());
 *   app.use('/api/billing', billingRoutes.router);
 *   app.post('/relay/:token', billingRoutes.requireActiveSubscription, relayHandler);
 *
 * ENV VARS
 *   STRIPE_SECRET_KEY=sk_live_...
 *   STRIPE_WEBHOOK_SECRET=whsec_...
 *   STRIPE_PRICE_ID=price_...
 *   APP_BASE_URL=https://your-relay-domain.com
 *   DATABASE_URL=postgres://...
 *   KEY_VAULT_ENCRYPTION_KEY=<64-char hex, see key-vault.js header>
 *
 * CHANGES FROM THE EARLIER DRAFT
 *   - /create-portal-session no longer trusts a client-supplied
 *     stripeCustomerId. That was an IDOR: anyone who knew or
 *     guessed a cus_... ID could open a STRANGER'S billing portal
 *     and see invoices / swap their card / cancel them. It now
 *     takes the subscriber's own webhookToken — the same token
 *     that gates their relay access — and resolves the Stripe
 *     customer ID server-side. The client never gets to choose
 *     whose portal it opens.
 *   - activateSubscriber / flagPastDue / deactivateSubscriber are
 *     all upserts in key-vault.js, so a duplicate Stripe webhook
 *     delivery (Stripe guarantees at-least-once, not exactly-once)
 *     just re-applies the same state instead of erroring or
 *     double-provisioning. No separate event-dedup table needed —
 *     keeps this lean, on purpose.
 */

const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const {
  activateSubscriber,
  flagPastDue,
  deactivateSubscriber,
  getSubscriberByToken,
} = require('../lib/key-vault');

// ----------------------------------------------------------------
// 1. CREATE CHECKOUT SESSION
// ----------------------------------------------------------------
router.post('/create-checkout-session', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });

  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      customer_email: email,
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      success_url: `${process.env.APP_BASE_URL}/dashboard?checkout=success`,
      cancel_url: `${process.env.APP_BASE_URL}/pricing?checkout=cancelled`,
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error('Stripe checkout session error:', err.message);
    res.status(500).json({ error: 'Could not start checkout' });
  }
});

// ----------------------------------------------------------------
// 2. CUSTOMER PORTAL — fixed: no more trusting a raw customer ID.
// Subscriber sends the SAME webhookToken they use for relay calls.
// We look up their Stripe customer ID ourselves.
// ----------------------------------------------------------------
router.post('/create-portal-session', async (req, res) => {
  const { webhookToken } = req.body;
  if (!webhookToken) return res.status(400).json({ error: 'Missing webhookToken' });

  try {
    const subscriber = await getSubscriberByToken(webhookToken);
    if (!subscriber || !subscriber.stripe_customer_id) {
      return res.status(404).json({ error: 'No billing account found for this token' });
    }

    const portalSession = await stripe.billingPortal.sessions.create({
      customer: subscriber.stripe_customer_id,
      return_url: `${process.env.APP_BASE_URL}/dashboard`,
    });
    res.json({ url: portalSession.url });
  } catch (err) {
    console.error('Stripe portal session error:', err.message);
    res.status(500).json({ error: 'Could not open billing portal' });
  }
});

// ----------------------------------------------------------------
// 3. WEBHOOK HANDLER
// ----------------------------------------------------------------
async function webhookHandler(req, res) {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const result = await activateSubscriber({
        email: session.customer_email,
        stripeCustomerId: session.customer,
        stripeSubscriptionId: session.subscription,
      });
      console.log(
        result.isNew
          ? `New subscriber activated: ${result.email} (token: ${result.webhookToken})`
          : `Returning subscriber reactivated: ${result.email}`
      );
      // TODO: email result.webhookToken + their relay URL to the subscriber.
      // That token doubles as their login (portal access) and their relay URL.
      break;
    }
    case 'invoice.payment_failed': {
      const invoice = event.data.object;
      await flagPastDue(invoice.customer);
      console.log(`Payment failed, flagged past_due: ${invoice.customer}`);
      break;
    }
    case 'customer.subscription.deleted': {
      const subscription = event.data.object;
      await deactivateSubscriber(subscription.customer);
      console.log(`Subscription cancelled, access revoked: ${subscription.customer}`);
      break;
    }
    default:
      break;
  }

  res.json({ received: true });
}

// ----------------------------------------------------------------
// 4. ACCESS GATE MIDDLEWARE
// ----------------------------------------------------------------
async function requireActiveSubscription(req, res, next) {
  const { token } = req.params;
  const subscriber = await getSubscriberByToken(token);

  if (!subscriber || (subscriber.status !== 'active' && subscriber.status !== 'past_due')) {
    return res.status(402).json({ error: 'Subscription inactive' });
  }

  req.subscriber = subscriber;
  next();
}

module.exports = { router, webhookHandler, requireActiveSubscription };

/**
 * ============================================================
 * KBC S2S Middleware — Key Vault
 * ============================================================
 * Two jobs:
 *   1. Track subscriber billing state (subscribers table) —
 *      called from routes/billing.js.
 *   2. Store each subscriber's OWN Impact.com / PartnerStack
 *      API credentials, encrypted at rest (provider_keys table).
 *      This is what makes the relay multi-tenant: every subscriber
 *      brings their own affiliate-network keys, you never touch
 *      their tracking data directly — you just relay it on their
 *      behalf using their credentials.
 *
 * REQUIRES
 *   npm install pg
 *
 * ENV VARS
 *   DATABASE_URL=postgres://user:pass@host:5432/dbname
 *   KEY_VAULT_ENCRYPTION_KEY=<64 hex chars = 32 bytes>
 *     Generate one with:
 *       node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
 *     Store this OUTSIDE git, in your host's env config. If you
 *     lose it, every stored provider key becomes undecryptable —
 *     back it up somewhere safe (password manager, not a text
 *     file in the repo).
 *
 * RUN schema.sql AGAINST YOUR DATABASE ONCE before using this file.
 */

const crypto = require('crypto');
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const ALGO = 'aes-256-gcm';
const ENCRYPTION_KEY = Buffer.from(process.env.KEY_VAULT_ENCRYPTION_KEY || '', 'hex');

if (ENCRYPTION_KEY.length !== 32) {
  console.warn(
    '⚠️  KEY_VAULT_ENCRYPTION_KEY is missing or not 32 bytes (64 hex chars). ' +
    'Provider-key encryption will fail until this is fixed.'
  );
}

function encrypt(plainText) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, ENCRYPTION_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return {
    encrypted: encrypted.toString('hex'),
    iv: iv.toString('hex'),
    authTag: authTag.toString('hex'),
  };
}

function decrypt({ encrypted, iv, authTag }) {
  const decipher = crypto.createDecipheriv(ALGO, ENCRYPTION_KEY, Buffer.from(iv, 'hex'));
  decipher.setAuthTag(Buffer.from(authTag, 'hex'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(encrypted, 'hex')),
    decipher.final(),
  ]);
  return decrypted.toString('utf8');
}

function generateWebhookToken() {
  return crypto.randomBytes(24).toString('hex'); // 48-char token
}

// ----------------------------------------------------------------
// SUBSCRIBER STATE (called from routes/billing.js)
// ----------------------------------------------------------------

async function activateSubscriber({ email, stripeCustomerId, stripeSubscriptionId }) {
  const existing = await pool.query('SELECT * FROM subscribers WHERE email = $1', [email]);

  if (existing.rows.length > 0) {
    const updated = await pool.query(
      `UPDATE subscribers
       SET status = 'active', stripe_customer_id = $1, stripe_subscription_id = $2, updated_at = now()
       WHERE email = $3
       RETURNING *`,
      [stripeCustomerId, stripeSubscriptionId, email]
    );
    return { isNew: false, email, webhookToken: updated.rows[0].webhook_token };
  }

  const webhookToken = generateWebhookToken();
  const inserted = await pool.query(
    `INSERT INTO subscribers (email, stripe_customer_id, stripe_subscription_id, status, webhook_token)
     VALUES ($1, $2, $3, 'active', $4)
     RETURNING *`,
    [email, stripeCustomerId, stripeSubscriptionId, webhookToken]
  );
  return { isNew: true, email, webhookToken: inserted.rows[0].webhook_token };
}

async function flagPastDue(stripeCustomerId) {
  await pool.query(
    `UPDATE subscribers SET status = 'past_due', updated_at = now() WHERE stripe_customer_id = $1`,
    [stripeCustomerId]
  );
}

async function deactivateSubscriber(stripeCustomerId) {
  await pool.query(
    `UPDATE subscribers SET status = 'canceled', updated_at = now() WHERE stripe_customer_id = $1`,
    [stripeCustomerId]
  );
}

async function getSubscriberByToken(token) {
  const result = await pool.query('SELECT * FROM subscribers WHERE webhook_token = $1', [token]);
  return result.rows[0] || null;
}

// ----------------------------------------------------------------
// PER-SUBSCRIBER PROVIDER KEYS — what makes the relay multi-tenant.
// Call setProviderKeys once when a subscriber connects their own
// Impact.com / PartnerStack account (e.g. a "Connect your affiliate
// accounts" screen in their dashboard). Call getDecryptedProviderKeys
// inside the relay handler right before forwarding their tracking call.
// ----------------------------------------------------------------

async function setProviderKeys(subscriberId, provider, { apiKey, apiSecret }) {
  const encKey = encrypt(apiKey);
  const encSecret = apiSecret ? encrypt(apiSecret) : null;

  await pool.query(
    `INSERT INTO provider_keys (subscriber_id, provider, encrypted_api_key, key_iv, key_auth_tag,
                                 encrypted_api_secret, secret_iv, secret_auth_tag)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     ON CONFLICT (subscriber_id, provider)
     DO UPDATE SET encrypted_api_key = EXCLUDED.encrypted_api_key,
                    key_iv = EXCLUDED.key_iv,
                    key_auth_tag = EXCLUDED.key_auth_tag,
                    encrypted_api_secret = EXCLUDED.encrypted_api_secret,
                    secret_iv = EXCLUDED.secret_iv,
                    secret_auth_tag = EXCLUDED.secret_auth_tag`,
    [
      subscriberId,
      provider,
      encKey.encrypted,
      encKey.iv,
      encKey.authTag,
      encSecret ? encSecret.encrypted : null,
      encSecret ? encSecret.iv : null,
      encSecret ? encSecret.authTag : null,
    ]
  );
}

async function getDecryptedProviderKeys(subscriberId, provider) {
  const result = await pool.query(
    'SELECT * FROM provider_keys WHERE subscriber_id = $1 AND provider = $2',
    [subscriberId, provider]
  );
  const row = result.rows[0];
  if (!row) return null;

  return {
    apiKey: decrypt({ encrypted: row.encrypted_api_key, iv: row.key_iv, authTag: row.key_auth_tag }),
    apiSecret: row.encrypted_api_secret
      ? decrypt({ encrypted: row.encrypted_api_secret, iv: row.secret_iv, authTag: row.secret_auth_tag })
      : null,
  };
}

module.exports = {
  activateSubscriber,
  flagPastDue,
  deactivateSubscriber,
  getSubscriberByToken,
  setProviderKeys,
  getDecryptedProviderKeys,
};

-- ============================================================
-- KBC S2S Middleware — Subscriber + Provider Key Schema
-- Run once against your Postgres database before using
-- lib/key-vault.js or routes/billing.js.
-- ============================================================

CREATE TABLE IF NOT EXISTS subscribers (
  id                      SERIAL PRIMARY KEY,
  email                   TEXT NOT NULL UNIQUE,
  stripe_customer_id      TEXT UNIQUE,
  stripe_subscription_id  TEXT,
  status                  TEXT NOT NULL DEFAULT 'inactive'
                            CHECK (status IN ('active', 'past_due', 'canceled', 'inactive')),
  webhook_token           TEXT NOT NULL UNIQUE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_subscribers_webhook_token ON subscribers (webhook_token);
CREATE INDEX IF NOT EXISTS idx_subscribers_stripe_customer_id ON subscribers (stripe_customer_id);

-- Each subscriber's OWN Impact.com / PartnerStack credentials,
-- encrypted at rest with AES-256-GCM (see key-vault.js).
-- This is what lets one hosted relay serve many subscribers
-- without ever mixing one company's affiliate data with another's.
CREATE TABLE IF NOT EXISTS provider_keys (
  id                      SERIAL PRIMARY KEY,
  subscriber_id           INTEGER NOT NULL REFERENCES subscribers(id) ON DELETE CASCADE,
  provider                TEXT NOT NULL CHECK (provider IN ('impact', 'partnerstack')),
  encrypted_api_key       TEXT NOT NULL,
  key_iv                  TEXT NOT NULL,
  key_auth_tag            TEXT NOT NULL,
  encrypted_api_secret    TEXT,
  secret_iv               TEXT,
  secret_auth_tag         TEXT,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (subscriber_id, provider)
);
